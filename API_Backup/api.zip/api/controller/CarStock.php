<?php
namespace Controller;

use \Psr\Http\Message\ResponseInterface as Response;
use \Psr\Http\Message\ServerRequestInterface as Request;

class CarStock
{
    public function insert_update_Request(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;

        // $imgOut = "";
        // if (empty(@$rawdata["img"])) {
        //     $imgOut = "";
        // } else {
        //     $imgpath = "./storage/imgcar/";
        //     $filename = uniqid(rand(), true) . '.png';
        //     $imgOut = $this->base64_to_jpeg($rawdata["img"], $imgpath . $filename);
        // }

        if (@$rawdata["insertStatus"] == true) {
            $query = $db->query("INSERT INTO `car_stock` (`img`,
              `brand`,
              `model`,
              `vehicle_type`,
              `color`,
              `oil_type`,
              `registration_number`,
              `year_buy`,
              `seat_size`,
              `delete_at`
              ) VALUES ('" . @$rawdata["img"] . "' ,
              '" . @$rawdata["brand"] . "' ,
              '" . @$rawdata["model"] . "' ,
              '" . @$rawdata["vehicle_type"] . "' ,
              '" . @$rawdata["color"] . "' ,
              '" . @$rawdata["oil_type"] . "' ,
              '" . @$rawdata["registration_number"] . "' ,
              '" . @$rawdata["year_buy"] . "',
              '" . @$rawdata["seat_size"] . "',
              null
            )");
        } else {
            $query = $db->query("UPDATE `car_stock`
              SET `img` = '" . $rawdata["img"] . "',
              `brand` = '" . $rawdata["brand"] . "',
              `model` = '" . $rawdata["model"] . "',
              `vehicle_type` = '" . $rawdata["vehicle_type"] . "',
              `color` = '" . $rawdata["color"] . "',
              `oil_type` = '" . $rawdata["oil_type"] . "',
              `registration_number` = '" . $rawdata["registration_number"] . "',
              `year_buy` = '" . $rawdata["year_buy"] . "',
              `seat_size` = '" . $rawdata["seat_size"] . "'
              WHERE `id` = '" . $rawdata["id"] . "'
              LIMIT 1
            ");
        }

        if ($query["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $finderror2 = "Duplicate";
            $finderror1 = "Data too long";
            if (strpos($query["result"], $finderror1) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูลบางส่วนมีความยาวมากเกินไป",
                );
            } else if (strpos($query["result"], $finderror2) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูลบางส่วนมีการใช้งานแล้ว",
                );
            } else {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "error",
                );
            }
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function delete_Request(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $delDate = date("Y-m-d H:i:s ");
        $query = $db->query("UPDATE `car_stock`
            SET `delete_at` = '" . $delDate . "'
            WHERE `id` = '" . $rawdata["id"] . "'
            LIMIT 1
        ");
        if ($query["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $dataOut = array(
                "success" => false,
                "result" => array_merge(
                    $query
                ),
                "message" => "error",
            );
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function getCarStock(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $query = $db->query("SELECT * FROM car_stock WHERE delete_at IS NULL");
        $dataOut = array(
            "success" => true,
            "result" => array_merge(
                $query
            ),
            "message" => "สำเร็จ",
        );
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function get_Usable_Driver_Car(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $queryCar = $db->query("
        SELECT * FROM car_stock WHERE car_stock.id NOT IN
        (SELECT request_car_detail.id_car FROM
        (SELECT * FROM request_car WHERE (mystep BETWEEN 1 AND 3) AND (('" . @$rawdata["date_start"] . "' BETWEEN date_start AND date_end) OR ('" . @$rawdata["date_end"] . "' BETWEEN date_start AND date_end))) AS d_request_car
        LEFT JOIN request_car_detail ON d_request_car.id = request_car_detail.id_request)
        ");
        $queryDriver = $db->query("
        SELECT * FROM users WHERE users.myrole = '5' AND users.username NOT IN
        (SELECT request_car_detail.user_driver FROM
        (SELECT * FROM request_car WHERE (mystep BETWEEN 1 AND 3) AND (('" . @$rawdata["date_start"] . "' BETWEEN date_start AND date_end) OR ('" . @$rawdata["date_end"] . "' BETWEEN date_start AND date_end))) AS d_request_car
        LEFT JOIN request_car_detail ON d_request_car.id = request_car_detail.id_request)
        ");

        $dataOut = array(
            "success" => true,
            "resultcar" => array_merge(
                $queryCar
            ),
            "resultdriver" => array_merge(
                $queryDriver
            ),
            "message" => "สำเร็จ",
        );

        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    private function base64_to_jpeg($base64_string, $output_file)
    {
        try {
            // open the output file for writing
            $ifp = fopen($output_file, 'wb');

            // split the string on commas
            // $data[ 0 ] == "data:image/png;base64"
            // $data[ 1 ] == <actual base64 string>
            $data = explode(',', $base64_string);

            // we could add validation here with ensuring count( $data ) > 1
            fwrite($ifp, base64_decode($data[1]));

            // clean up the file resource
            fclose($ifp);
        } catch (Exception $e) {
            $output_file = "";
        }

        return $output_file;
    }
}
