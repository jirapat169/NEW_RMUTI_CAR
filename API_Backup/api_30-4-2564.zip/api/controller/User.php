<?php
namespace Controller;

use \Psr\Http\Message\ResponseInterface as Response;
use \Psr\Http\Message\ServerRequestInterface as Request;

class User
{
    public function loginmanual(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $query = $db->query("SELECT d_users.*,GROUP_CONCAT(roles.role_username) AS role_username,GROUP_CONCAT(roles.role) AS role FROM (SELECT users.* FROM users WHERE `username` = '" . $rawdata["username"] . "' OR `email` = '" . $rawdata["username"] . "' LIMIT 1) AS d_users LEFT JOIN roles ON d_users.username = roles.username");
        if ($query['isQuery'] && $query['rowCount'] > 0) {
            if ($query['result'][0]['password'] == md5($rawdata["password"])) {
                unset($query['result'][0]['password']);
                $dataOut = array(
                    "success" => true,
                    "result" => array_merge(
                        $query['result'][0]
                    ),
                    "message" => "สำเร็จ",
                );
            } else {
                $dataOut = array(
                    "success" => false,
                    "result" => null,
                    "message" => "รหัสผ่านไม่ถูกต้อง",
                );
            }
        } else {
            $dataOut = array(
                "success" => false,
                "result" => null,
                "message" => "ไม่พบชื่อผู้ใช้งาน",
            );
        }

        $response->getBody()->write(\json_encode($dataOut));
        return $response;

    }

    public function registermanual(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        if (@$rawdata["insertStatus"] == true) {
            $query = $db->query("INSERT INTO `users` (`username`,
                `img`,
                `myrole`,
                `prename`,
                `firstname`,
                `lastname`,
                `personal_id`,
                `password`,
                `position`,
                `phone_number`,
                `email`
                ) VALUES ('" . @$rawdata["username"] . "' ,
                '" . @$rawdata["img"] . "' ,
                '" . @$rawdata["myrole"] . "' ,
                '" . @$rawdata["prename"] . "' ,
                '" . @$rawdata["firstname"] . "' ,
                '" . @$rawdata["lastname"] . "' ,
                '" . @$rawdata["personal_id"] . "' ,
                '" . md5(@$rawdata["password"]) . "' ,
                '" . @$rawdata["position"] . "',
                '" . @$rawdata["phone_number"] . "' ,
                '" . @$rawdata["email"] . "'
            )");
        } else {
            $query = $db->query("UPDATE `users`
                SET `img` = '" . $rawdata["img"] . "',
                `myrole` = '" . $rawdata["myrole"] . "',
                `prename` = '" . $rawdata["prename"] . "',
                `firstname` = '" . $rawdata["firstname"] . "',
                `lastname` = '" . $rawdata["lastname"] . "',
                `personal_id` = '" . $rawdata["personal_id"] . "',
                `position` = '" . $rawdata["position"] . "',
                `phone_number` = '" . $rawdata["phone_number"] . "',
                `email` = '" . $rawdata["email"] . "'
                WHERE `username` = '" . $rawdata["username"] . "'
                LIMIT 1
            ");
        }

        if ($query["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $finderror1 = "Data too long";
            $finderror2 = "key 'PRIMARY'";
            $finderror3 = "key 'email'";
            if (strpos($query["result"], $finderror1) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูลบางส่วนมีความยาวมากเกินไป",
                );
            } else if (strpos($query["result"], $finderror2) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูล Username มีการใช้แล้ว",
                );
            } else if (strpos($query["result"], $finderror3) != false) {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "ข้อมูล Email มีการใช้แล้ว",
                );
            } else {
                $dataOut = array(
                    "success" => false,
                    "result" => array_merge(
                        $query
                    ),
                    "message" => "error",
                );
            }
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function getUsers(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $query = $db->query("SELECT * FROM users");
        $dataOut = array(
            "success" => true,
            "result" => array_merge(
                $query
            ),
            "message" => "สำเร็จ",
        );
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function delete_User(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $dataOut = null;
        $delDate = date("Y-m-d H:i:s ");
        $query = $db->query("DELETE FROM users
            WHERE `username` = '" . $rawdata["username"] . "'
            LIMIT 1
        ");
        if ($query["isQuery"]) {
            $dataOut = array(
                "success" => true,
                "result" => array_merge(
                    $query
                ),
                "message" => "สำเร็จ",
            );
        } else {
            $dataOut = array(
                "success" => false,
                "result" => array_merge(
                    $query
                ),
                "message" => "error",
            );
        }
        $response->getBody()->write(\json_encode($dataOut));
        return $response;
    }

    public function addRoles(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $query = $db->query("INSERT INTO `roles` (
        `username`,
        `role_username`,
        `role`
        ) VALUES (
        '" . @$rawdata["username"] . "' ,
        '" . @$rawdata["role_username"] . "' ,
        '" . @$rawdata["role"] . "'
        )");

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function getRoles(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();
        $query = $db->query("SELECT * FROM `roles`
        LEFT JOIN `users`
        ON `users`.`username` = `roles`.`username`
        WHERE `roles`.`role_username` = '" . @$rawdata["username"] . "'");

        $response->getBody()->write(\json_encode($query));
        return $response;
    }

    public function deleteRoles(Request $request, Response $response, $args)
    {
        $rawdata = \json_decode(file_get_contents("php://input"), true);
        $db = new \Tools\Database();

        $query = $db->query("DELETE FROM `roles`
            WHERE `username` = '" . @$rawdata["username"] . "'
            AND `role_username` = '" . @$rawdata["role_username"] . "'
            LIMIT 1
        ");

        $response->getBody()->write(\json_encode($query));
        return $response;
    }
}
